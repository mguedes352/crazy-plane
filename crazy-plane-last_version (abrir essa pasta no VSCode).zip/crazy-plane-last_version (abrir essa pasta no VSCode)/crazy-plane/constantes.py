import pygame

pygame.init()

# -- TELA
LARGURA = 900
ALTURA = 500

# -- CORES
AZULCLARO = ((173, 216, 230))
ROXO = ((48, 23, 45))
VERMELHO = ((255, 0, 0))
VERDE = ((0, 255, 0))
AMARELO = ((255, 255, 0))
BRANCO = ((255, 255, 255))

# -- TAXA DE QUADROS
FPS = 120

# -- FONTE DO TEXTO
FONTE = pygame.font.SysFont('segoeuiblack', 32)
FONTE1 = 'segoeuiblack'
FONTE2 = pygame.font.SysFont('arial', 20)